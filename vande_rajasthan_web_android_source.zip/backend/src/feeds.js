// Google News RSS search feeds. Headlines/snippets are attributed to the publisher
// shown in each item; verify publisher terms and local news coverage before production.
const q = (term) => `https://news.google.com/rss/search?q=${encodeURIComponent(term)}&hl=hi&gl=IN&ceid=IN:hi`;
export const FEEDS = [
  { name: "Google News · राजस्थान", url: q("राजस्थान समाचार when:3d"), category: "राजस्थान" },
  { name: "Google News · भारत", url: q("भारत राष्ट्रीय समाचार when:3d"), category: "राष्ट्रीय" },
  { name: "Google News · विश्व", url: q("विश्व अंतरराष्ट्रीय समाचार when:3d"), category: "अंतरराष्ट्रीय" },
  { name: "Google News · शिक्षा", url: q("भारत शिक्षा परीक्षा when:3d"), category: "शिक्षा" },
  { name: "Google News · खेल", url: q("भारत खेल समाचार when:3d"), category: "खेल" },
];
