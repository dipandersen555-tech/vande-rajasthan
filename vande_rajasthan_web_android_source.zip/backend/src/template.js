
const esc = s => String(s || "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const pageSections = [
  { title:"राजस्थान विशेष", cats:["राजस्थान","राजनीति"] },
  { title:"राष्ट्रीय समाचार", cats:["राष्ट्रीय","राजनीति"] },
  { title:"अंतरराष्ट्रीय समाचार", cats:["अंतरराष्ट्रीय"] },
  { title:"शिक्षा, खेल और विविध", cats:["शिक्षा","खेल"] },
];
export function newspaperHtml(news, dateLabel) {
  const chosen = pageSections.map((p,idx) => {
    let list = news.filter(n => p.cats.includes(n.category));
    if (list.length < 6) list = list.concat(news.filter(n => !list.includes(n)));
    const take = idx===3 ? 12 : 12;
    return { ...p, items:list.slice(0,take) };
  });
  // Make each page's list different where possible, then fill from the remaining feed.
  const used = new Set();
  for (const p of chosen) {
    p.items = p.items.filter(n => !used.has(n.url));
    p.items.forEach(n => used.add(n.url));
    if (p.items.length < 8) {
      for (const n of news) {
        if (!used.has(n.url)) { p.items.push(n); used.add(n.url); }
        if (p.items.length >= 12) break;
      }
    }
  }
  return `<!doctype html><html lang="hi"><head><meta charset="utf-8">
  <style>
  @page { size:A3 landscape; margin:7mm; }
  *{box-sizing:border-box} body{font-family:"Noto Sans Devanagari","Nirmala UI",sans-serif;color:#111;margin:0}
  .page{height:282mm;page-break-after:always;overflow:hidden;border-bottom:2px solid #111;padding:0 1mm}
  .masthead{border-top:1mm solid #111;border-bottom:1.2mm solid #111;text-align:center;padding:1mm 0 1.5mm;background:#e8e8e8}
  .brand{font-size:39pt;font-weight:950;letter-spacing:1px;line-height:1.05;color:#080808}
  .mastrow{display:grid;grid-template-columns:28mm 1fr 42mm;gap:2mm;align-items:center}.logobox{border:1px solid #111;background:#ddd;font-size:7pt;line-height:1.25;padding:2mm;font-weight:bold}.adbox{border:1px solid #111;background:#ddd;font-size:7pt;line-height:1.25;padding:2mm}.tagline{font-size:7pt;letter-spacing:1px;color:#222;font-weight:bold;margin-top:1mm}.meta{display:flex;justify-content:space-between;font-size:8pt;border-top:1px solid #111;margin-top:1.5mm;padding-top:1mm;font-weight:bold}
  .lead{font-size:19pt;line-height:1.22;font-weight:900;margin:3mm 0 2mm}
  .strap{background:#222;color:#fff;font-size:10pt;font-weight:bold;padding:1.5mm 3mm;margin-bottom:2mm}
  .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:3mm}
  article{border-right:1px solid #aaa;padding-right:2mm;break-inside:avoid;overflow:hidden}
  h2{font-size:12pt;line-height:1.24;margin:0 0 1.5mm}
  p{font-size:8.1pt;line-height:1.42;margin:0 0 1.5mm;text-align:justify}
  .source{font-size:6.8pt;color:#555;margin-top:1mm;overflow-wrap:anywhere}
  .category{font-size:8pt;font-weight:bold;border-bottom:1px solid #888;margin:2mm 0 1mm;padding-bottom:1mm}
  .footer{font-size:8pt;border-top:2px solid #111;margin-top:2mm;padding-top:1mm;display:flex;justify-content:space-between}
  .empty{font-size:13pt;padding:8mm;text-align:center}
  </style></head><body>
  ${chosen.map((p,i)=>`<section class="page">
    <header class="masthead"><div class="mastrow"><div class="logobox">वन्दे राजस्थान<br/>दैनिक समाचार<br/>जयपुर, राजस्थान</div><div><div class="brand">वन्दे राजस्थान</div><div class="tagline">सत्य · निष्पक्षता · जनहित</div></div><div class="adbox">विज्ञापन एवं समाचार<br/>के लिए संपर्क करें<br/>संपादकीय कार्यालय</div></div><div class="meta"><span>दैनिक हिंदी समाचार पत्र</span><strong>${esc(dateLabel)}</strong><span>संस्करण: दैनिक · पृष्ठ ${i+1}/4</span></div></header>
    <div class="lead">${esc(p.items[0]?.title || p.title)}</div><div class="strap">${p.title} · ताज़ा समाचार</div>
    ${p.items.length ? `<div class="grid">${p.items.slice(1).map(n=>`<article><div class="category">${esc(n.category)}</div><h2>${esc(n.title)}</h2><p>${esc(n.summary || "इस खबर का विवरण मूल स्रोत पर पढ़ें।")}</p><div class="source">स्रोत: ${esc(n.source)} · <a href="${esc(n.url)}">मूल खबर</a></div></article>`).join("")}</div>` : `<div class="empty">इस पेज के लिए पर्याप्त सत्यापित समाचार उपलब्ध नहीं हैं। प्रकाशन से पहले समाचार फ़ीड की जाँच करें।</div>`}
    <div class="footer"><span>वन्दे राजस्थान</span><span>मूल स्रोत और प्रकाशन समय देखें</span><span>पृष्ठ ${i+1}/4</span></div>
  </section>`).join("")}
  </body></html>`;
}
