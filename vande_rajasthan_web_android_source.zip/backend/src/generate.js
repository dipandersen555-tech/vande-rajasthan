
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import puppeteer from "puppeteer";
import { fetchNews } from "./news.js";
import { newspaperHtml } from "./template.js";
const here = path.dirname(fileURLToPath(import.meta.url));
const outputDir = path.resolve(here, "../public/issues");
await fs.mkdir(outputDir, { recursive: true });
export async function generateIssue() {
  const news = await fetchNews();
  if (news.length < 12) throw new Error(`केवल ${news.length} ताज़ा समाचार मिले। चार पेज प्रकाशित करने से पहले RSS स्रोत जोड़ें/जाँचें (कम-से-कम 12 की जरूरत, बेहतर परिणाम के लिए 40+)।`);
  const now = new Date();
  const day = new Intl.DateTimeFormat("hi-IN", { dateStyle:"long", timeZone:"Asia/Kolkata" }).format(now);
  const stamp = new Intl.DateTimeFormat("en-CA", { timeZone:"Asia/Kolkata", year:"numeric", month:"2-digit", day:"2-digit" }).format(now);
  const html = newspaperHtml(news, day);
  await fs.writeFile(path.join(outputDir, `${stamp}.html`), html, "utf8");
  const browser = await puppeteer.launch({ headless:true, args:["--no-sandbox","--disable-setuid-sandbox"] });
  try {
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil:"networkidle0" });
    await page.pdf({ path:path.join(outputDir, `${stamp}.pdf`), format:"A3", landscape:true, printBackground:true, preferCSSPageSize:true });
  } finally { await browser.close(); }
  const manifest = { date:day, stamp, count:news.length, pdf:`/issues/${stamp}.pdf`, generatedAt:now.toISOString() };
  await fs.writeFile(path.join(outputDir,"latest.json"), JSON.stringify(manifest,null,2));
  const historyPath = path.join(outputDir,"history.json");
  let history=[];
  try { history=JSON.parse(await fs.readFile(historyPath,"utf8")); } catch {}
  history=[manifest,...history.filter(x=>x.stamp!==stamp)].slice(0,90);
  await fs.writeFile(historyPath,JSON.stringify(history,null,2));
  return manifest;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) console.log(await generateIssue());
