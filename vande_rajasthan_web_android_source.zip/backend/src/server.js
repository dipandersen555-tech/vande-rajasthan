
import "dotenv/config";
import express from "express";
import cors from "cors";
import cron from "node-cron";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { generateIssue } from "./generate.js";
const app=express(); app.use(cors()); app.use(express.json());
const here=path.dirname(fileURLToPath(import.meta.url));
const issuesDir=path.resolve(here,"../public/issues");
app.use("/issues",express.static(issuesDir));
app.use(express.static(path.resolve(here, "../public")));
app.get("/api/health",(_req,res)=>res.json({ok:true,service:"Vande Rajasthan"}));
app.get("/api/latest",async(_req,res)=>{
 try{res.json(JSON.parse(await fs.readFile(path.join(issuesDir,"latest.json"),"utf8")))}
 catch{res.status(404).json({error:"अभी कोई अंक उपलब्ध नहीं है।"})}
});
app.get("/api/history",async(_req,res)=>{
 try{res.json(JSON.parse(await fs.readFile(path.join(issuesDir,"history.json"),"utf8")))}
 catch{res.json([])}
});
app.post("/api/generate",async(req,res)=>{
 const token=process.env.ADMIN_TOKEN;
 if(!token) return res.status(503).json({error:"सुरक्षा के लिए ADMIN_TOKEN सेट करने के बाद ही मैन्युअल निर्माण चालू होगा।"});
 if(req.get("x-admin-token")!==token) return res.status(401).json({error:"Unauthorized"});
 try{res.json(await generateIssue())}catch(e){console.error(e);res.status(500).json({error:e.message})}
});
cron.schedule("0 6 * * *",async()=>{
 try{console.log("Daily PDF generated:",await generateIssue())}
 catch(e){console.error("Daily PDF failed:",e)}
},{timezone:"Asia/Kolkata"});
const port=Number(process.env.PORT||8787);
app.listen(port,()=>console.log(`Vande Rajasthan backend on :${port}`));
