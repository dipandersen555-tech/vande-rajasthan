
import Parser from "rss-parser";
import { FEEDS } from "./feeds.js";
const parser = new Parser({ timeout: 15000, headers: { "User-Agent": "VandeRajasthanNews/0.2 (news aggregation; contact publisher before production)" } });
const categoryRules = [
  ["राजस्थान", /rajasthan|राजस्थान|जयपुर|जोधपुर|उदयपुर|कोटा|अजमेर|बीकानेर|सीकर|पाली|अलवर/i],
  ["राजनीति", /politic|election|चुनाव|सरकार|विधानसभा|लोकसभा|मंत्री|मुख्यमंत्री|संसद/i],
  ["राष्ट्रीय", /india|national|भारत|दिल्ली|भारतीय|केंद्र सरकार|मंत्रालय/i],
  ["अंतरराष्ट्रीय", /world|international|global|अमेरिका|पाकिस्तान|चीन|संयुक्त राष्ट्र|यूरोप|रूस|यूक्रेन/i],
  ["शिक्षा", /education|school|college|exam|शिक्षा|परीक्षा|विश्वविद्यालय|बोर्ड परीक्षा/i],
  ["खेल", /sport|cricket|football|खेल|क्रिकेट|ओलंपिक/i],
];
function categoryFor(text, fallback) {
  return categoryRules.find(([,re]) => re.test(text))?.[0] || fallback || "राष्ट्रीय";
}
export async function fetchNews() {
  const all = [];
  for (const feed of FEEDS) {
    try {
      const parsed = await parser.parseURL(feed.url);
      for (const item of (parsed.items || [])) {
        const title = (item.title || "").trim();
        const url = item.link || "";
        if (!title || !url) continue;
        const date = new Date(item.isoDate || item.pubDate || Date.now());
        if (Number.isNaN(date.getTime())) continue;
        // Ignore old feed items (default: 72 hours) so yesterday's items don't dominate.
        if (Date.now() - date.getTime() > 72 * 60 * 60 * 1000) continue;
        const splitTitle = title.split(" - ");
        const publisherFromTitle = splitTitle.length > 1 ? splitTitle.pop().trim() : "";
        const cleanTitle = splitTitle.join(" - ").trim() || title;
        all.push({
          title: cleanTitle, url, source: publisherFromTitle || feed.name || parsed.title || new URL(feed.url).hostname,
          category: categoryFor(title + " " + (item.contentSnippet || ""), feed.category),
          summary: (item.contentSnippet || item.content || "").replace(/<[^>]*>/g, " ").replace(/\s+/g," ").trim().slice(0, 560),
          publishedAt: date.toISOString()
        });
      }
    } catch (e) { console.error("RSS feed failed:", feed.url, e.message); }
  }
  const seen = new Set();
  const unique = all.filter(n => {
    const key = n.title.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
    if (seen.has(key)) return false;
    seen.add(key); return true;
  }).sort((a,b) => new Date(b.publishedAt) - new Date(a.publishedAt));
  // Balance sections so one busy feed doesn't fill all four pages.
  const result = [];
  const buckets = new Map();
  for (const n of unique) {
    if (!buckets.has(n.category)) buckets.set(n.category, []);
    buckets.get(n.category).push(n);
  }
  const keys = ["राजस्थान","राष्ट्रीय","राजनीति","अंतरराष्ट्रीय","शिक्षा","खेल", ...buckets.keys()];
  while (result.length < 48) {
    let added = false;
    for (const key of keys) {
      const arr = buckets.get(key);
      if (arr?.length) { result.push(arr.shift()); added = true; if (result.length >= 48) break; }
    }
    if (!added) break;
  }
  return result;
}
