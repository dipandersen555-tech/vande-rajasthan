# वन्दे राजस्थान — वेब ऐप + Android ऐप + दैनिक PDF

यह प्रोजेक्ट मोबाइल-फ्रेंडली वेब ऐप (PWA), Android ऐप का स्रोत कोड और A3 लैंडस्केप में चार पृष्ठ का PDF अखबार बनाने वाला Node.js सर्वर शामिल करता है। यह **तैयार/होस्ट किया हुआ उत्पाद नहीं है**: सर्वर तैनात करना, समाचार फ़ीड की जाँच, API URL सेट करना और APK build करना बाकी सेटअप चरण हैं।

## इसमें क्या है

- `backend/public/` — मोबाइल वेब ऐप, PWA manifest, आइकन और ऑफलाइन शेल कैश।
- `backend/src/feeds.js` — Google News RSS खोज फ़ीड: राजस्थान, भारत, विश्व, शिक्षा, खेल। फ़ीड का परिणाम समय/क्षेत्र के हिसाब से बदल सकता है।
- `backend/src/news.js` — RSS पढ़ना, 72 घंटे से पुरानी खबरें हटाना, डुप्लिकेट कम करना, स्रोत और मूल लिंक रखना।
- `backend/src/template.js` + `backend/src/generate.js` — चार पेज, A3 लैंडस्केप PDF बनाना और दैनिक अंक इतिहास रखना।
- `backend/src/server.js` — वेबसाइट और API, तथा सर्वर चालू रहने पर भारतीय समय के अनुसार सुबह 06:00 बजे cron।
- `android-app/` — Expo/React Native Android ऐप का स्रोत। `eas.json` में APK preview build प्रोफ़ाइल है।

## अपने कंप्यूटर पर चलाना

आवश्यक: Node.js 22 या नया, npm और Puppeteer/Chromium चलाने के लिए आवश्यक OS libraries।

```bash
cd backend
cp .env.example .env
npm install
npm start
```

फिर ब्राउज़र में `http://localhost:8787` खोलें। स्वास्थ्य जाँच: `http://localhost:8787/api/health`।

पहला अंक बनाने के लिए दूसरे टर्मिनल में:

```bash
cd backend
npm run generate
```

PDF `backend/public/issues/` में बनेगा। यदि RSS से 12 से कम ताज़ा समाचार मिले, तो जनरेटर जानबूझकर PDF प्रकाशित नहीं करेगा। प्रकाशन से पहले शीर्षक, स्रोत, तारीख़, खबर की प्रासंगिकता और कॉपीराइट/प्रकाशक की शर्तें जाँचें।

## वेब ऐप को मोबाइल पर इंस्टॉल करना

1. backend को HTTPS वाली होस्टिंग पर तैनात करें।
2. डोमेन पर `https://YOUR-DOMAIN/` खोलें।
3. Android Chrome मेनू में **Add to Home screen / होम स्क्रीन पर जोड़ें** चुनें।

PWA install prompt और service worker सामान्यतः HTTPS पर ही काम करते हैं (localhost अपवाद है)। यह ZIP अपने-आप सार्वजनिक URL नहीं बनाती।

## Android APK बनाना

1. Expo/EAS Build खाता और EAS CLI सेट करें।
2. `android-app/` में जाएँ और `npm install` करें।
3. सर्वर की असली HTTPS URL के साथ build चलाएँ:

```bash
cd android-app
npm install
npx eas-cli login
EXPO_PUBLIC_API_URL=https://YOUR-REAL-DOMAIN npx eas-cli build --platform android --profile preview
```

Build पूरा होने पर EAS एक APK डाउनलोड लिंक देगा। इस वातावरण में अभी APK build या device test नहीं किया गया है। किसी भी placeholder URL के साथ ऐप सही समाचार नहीं दिखाएगा।

## ऑनलाइन होस्टिंग और रोज़ सुबह 6 बजे

- सर्वर को HTTPS पर deploy करें और `PORT` hosting platform के अनुसार रखें। `Dockerfile` उपलब्ध है।
- `ADMIN_TOKEN` के लिए लंबा, निजी secret सेट करें। इसे सार्वजनिक न करें।
- PDF फ़ाइलों को स्थायी रखने के लिए persistent disk या अलग object storage आवश्यक हो सकती है। ephemeral/free hosting restart पर पुराने PDF मिटा सकती है।
- सर्वर-आधारित cron केवल तब चलता है जब server process चल रहा हो। Free hosting में sleep/usage limits हो सकती हैं; इसलिए रोज़ 06:00 IST प्रकाशन की गारंटी नहीं है। विश्वसनीय प्रकाशन के लिए always-on host या अलग scheduled job और persistent storage कॉन्फ़िगर करें।
- Google News RSS में publisher की खबरों के लिंक/संक्षिप्त अंश आ सकते हैं। अपने प्रकाशन के लिए स्रोतों की शर्तें जाँचें; पूरे लेख कॉपी न करें और तथ्य सत्यापित करें।

## API

- `GET /api/health` — सेवा स्थिति
- `GET /api/latest` — नवीनतम अंक
- `GET /api/history` — पिछले अंक
- `POST /api/generate` — मैन्युअल PDF निर्माण; production में `x-admin-token` के साथ उपयोग करें।

## अभी की वास्तविक स्थिति

यह **स्रोत कोड पैकेज** है, न कि पहले से ऑनलाइन चलने वाला ऐप। इस ZIP में कोई प्रकाशित URL, तैयार APK, सक्रिय सर्वर, सत्यापित live news edition या डिवाइस पर परीक्षण शामिल नहीं है। इन चरणों के लिए उपयोगकर्ता का hosting/Expo account setup और वास्तविक build आवश्यक है।
