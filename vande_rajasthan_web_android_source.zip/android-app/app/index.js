
import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, Pressable, ScrollView, Linking, ActivityIndicator, RefreshControl, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';
// Replace with your deployed HTTPS backend URL before production.
const API = (process.env.EXPO_PUBLIC_API_URL || 'https://YOUR-DOMAIN.example').replace(/\/$/, '');
export default function Home(){
 const [issue,setIssue]=useState(null),[history,setHistory]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState('');
 async function load(){
  setLoading(true);setError('');
  try{
   const r=await fetch(`${API}/api/latest`);const j=await r.json();
   if(!r.ok)throw new Error(j.error||'अंक नहीं मिला');setIssue(j);
   const hr=await fetch(`${API}/api/history`);if(hr.ok)setHistory(await hr.json());
  }catch(e){setError('अभी PDF सर्वर से कनेक्शन नहीं हुआ। होस्टिंग का HTTPS URL सेट करें।');}
  finally{setLoading(false)}
 }
 useEffect(()=>{load()},[]);
 const openPdf=(path)=>Linking.openURL(`${API}${path}`);
 return <SafeAreaView style={s.safe}><StatusBar style="dark"/><ScrollView contentContainerStyle={s.page} refreshControl={<RefreshControl refreshing={loading} onRefresh={load}/>}>
  <View style={s.masthead}><Text style={s.brand}>वन्दे राजस्थान</Text><Text style={s.tag}>दैनिक हिंदी समाचार पत्र</Text><View style={s.meta}><Text style={s.metaText}>{issue?.date||'आज का अंक'}</Text><Text style={s.metaText}>पृष्ठ 1–4</Text></View></View>
  <Text style={s.heading}>आज का ई-पेपर</Text><Text style={s.body}>राजस्थान · राष्ट्रीय · अंतरराष्ट्रीय</Text>
  {loading?<ActivityIndicator size="large" style={{margin:24}}/>:error?<Text style={s.error}>{error}</Text>:<View style={s.card}>
   <Text style={s.cardTitle}>आज का PDF अंक</Text><Text style={s.body}>समाचार: {issue?.count??'—'} · दैनिक संस्करण</Text>
   <Pressable style={s.button} onPress={()=>openPdf(issue.pdf)}><Text style={s.buttonText}>PDF डाउनलोड / खोलें</Text></Pressable>
   <Text style={s.small}>PDF प्रिंट करने योग्य अखबार के रूप में तैयार किया जाता है।</Text>
  </View>}
  <Text style={s.subheading}>पिछले अंक</Text>
  {history.length===0?<Text style={s.small}>पिछले अंक यहाँ दिखेंगे, जब सर्वर पर इतिहास उपलब्ध होगा।</Text>:history.map(item=><Pressable key={item.stamp} style={s.history} onPress={()=>openPdf(item.pdf)}><View style={{flex:1}}><Text style={s.historyTitle}>{item.date}</Text><Text style={s.small}>{item.count} समाचार</Text></View><Text style={s.link}>PDF खोलें ↗</Text></Pressable>)}
  <Pressable style={s.refresh} onPress={load}><Text style={s.secondaryText}>अंक अपडेट करें</Text></Pressable>
  <Text style={s.note}>खबरों के मूल स्रोत देखें। दैनिक प्रकाशन तभी चलेगा जब समाचार फ़ीड और ऑनलाइन सर्वर सही ढंग से कॉन्फ़िगर हों।</Text>
 </ScrollView></SafeAreaView>
}
const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#f1efe9'},page:{padding:18,paddingBottom:40},
 masthead:{backgroundColor:'#fff',borderColor:'#111',borderTopWidth:5,borderBottomWidth:5,padding:12,alignItems:'center'},
 brand:{fontSize:36,fontWeight:'900',color:'#111'},tag:{fontSize:12,color:'#333',marginTop:2},
 meta:{marginTop:10,paddingTop:7,borderTopWidth:1,borderColor:'#999',width:'100%',flexDirection:'row',justifyContent:'space-between'},
 metaText:{fontSize:12,fontWeight:'700',color:'#222'},heading:{fontSize:25,fontWeight:'900',marginTop:24,color:'#111'},
 body:{fontSize:15,lineHeight:23,color:'#444',marginTop:8},card:{backgroundColor:'#fff',padding:18,marginTop:20,borderWidth:1,borderColor:'#d0cbc0',borderRadius:8},
 cardTitle:{fontSize:19,fontWeight:'800',color:'#111'},button:{backgroundColor:'#171717',padding:15,borderRadius:6,marginTop:16,alignItems:'center'},
 buttonText:{color:'#fff',fontWeight:'800',fontSize:15},small:{fontSize:12,lineHeight:18,color:'#666',marginTop:10},
 subheading:{fontSize:20,fontWeight:'900',marginTop:26,marginBottom:8,color:'#111'},history:{backgroundColor:'#fff',padding:14,marginTop:8,borderRadius:6,flexDirection:'row',alignItems:'center'},
 historyTitle:{fontSize:15,fontWeight:'800',color:'#222'},link:{fontSize:13,fontWeight:'800',color:'#333'},refresh:{alignSelf:'center',padding:16,marginTop:8},
 secondaryText:{fontWeight:'700',color:'#222'},error:{color:'#a11',marginTop:18},note:{fontSize:12,lineHeight:18,color:'#666',marginTop:24}
});
